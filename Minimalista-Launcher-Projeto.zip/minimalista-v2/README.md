# Minimalista Launcher v1.2

Launcher Android nativo em Java, com tema preto/verde-limão.

## Recursos
- Relógio e data atualizados automaticamente.
- Lista de aplicativos instalados com os ícones originais do Android.
- Busca de aplicativos por nome.
- Painel de RAM usada/disponível e atualização manual.
- Toque longo em aplicativo para personalizar o símbolo ou ocultá-lo.
- Botão OCULTOS para restaurar aplicativos ocultos.
- Preferências salvas localmente.
- Pode ser escolhido como aplicativo de tela inicial (HOME).

Nota: o painel mede a memória informada pelo Android; não força o encerramento de outros apps. Gestos avançados de abrir aplicativos ainda não estão incluídos nesta versão.

## Compilar
Abra no Android Studio com JDK 17+ e SDK Android API 35, ou use o workflow GitHub Actions configurado no repositório. O APK de debug fica em `app/build/outputs/apk/debug/app-debug.apk`.
