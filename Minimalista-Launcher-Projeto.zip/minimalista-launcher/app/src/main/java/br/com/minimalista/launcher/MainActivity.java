package br.com.minimalista.launcher;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.format.DateFormat;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(16, 17, 16);
    private final int panel = Color.rgb(29, 31, 28);
    private final int fg = Color.rgb(241, 242, 236);
    private final int muted = Color.rgb(157, 163, 151);
    private final int accent = Color.rgb(184, 243, 107);
    private LinearLayout root;
    private TextView ramValue;
    private TextView ramDetail;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildUi();
    }

    @Override protected void onResume() {
        super.onResume();
        if (root != null) refreshRam();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(bg);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(28), dp(24), dp(28));
        scroll.addView(root);

        TextView brand = text("MINIMALISTA", 12, accent, true);
        brand.setLetterSpacing(0.18f);
        root.addView(brand);

        TextView clock = text(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()), 54, fg, false);
        clock.setPadding(0, dp(14), 0, 0);
        root.addView(clock);
        TextView date = text(new SimpleDateFormat("EEEE, d 'de' MMMM", new Locale("pt", "BR")).format(new Date()), 14, muted, false);
        date.setPadding(0, 0, 0, dp(26));
        root.addView(date);

        TextView ramTitle = text("MEMÓRIA DO SISTEMA", 11, muted, true);
        ramTitle.setLetterSpacing(0.12f);
        root.addView(ramTitle);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(round(panel, 18));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.topMargin = dp(10);
        cp.bottomMargin = dp(28);
        root.addView(card, cp);
        ramValue = text("--%", 34, fg, true);
        card.addView(ramValue);
        ramDetail = text("Lendo memória…", 13, muted, false);
        ramDetail.setPadding(0, dp(3), 0, dp(15));
        card.addView(ramDetail);
        Button refresh = button("ATUALIZAR LEITURA", true);
        card.addView(refresh, new LinearLayout.LayoutParams(-1, dp(46)));
        refresh.setOnClickListener(v -> refreshRam());

        TextView appsTitle = text("APLICATIVOS", 11, muted, true);
        appsTitle.setLetterSpacing(0.12f);
        root.addView(appsTitle);
        TextView hint = text("Toque para abrir", 12, muted, false);
        hint.setPadding(0, dp(4), 0, dp(12));
        root.addView(hint);
        addApps();

        Button settings = button("GERENCIAR APLICATIVOS", false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(48));
        sp.topMargin = dp(20);
        root.addView(settings, sp);
        settings.setOnClickListener(v -> {
            try { startActivity(new Intent(Settings.ACTION_APPLICATION_SETTINGS)); }
            catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
        });
        setContentView(scroll);
        refreshRam();
    }

    private void addApps() {
        PackageManager pm = getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN, null);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(query, 0);
        Collections.sort(apps, new Comparator<ResolveInfo>() {
            @Override public int compare(ResolveInfo a, ResolveInfo b) {
                return a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString());
            }
        });
        String own = getPackageName();
        int shown = 0;
        for (ResolveInfo info : apps) {
            if (info.activityInfo == null || own.equals(info.activityInfo.packageName)) continue;
            String label = info.loadLabel(pm).toString();
            LinearLayout item = new LinearLayout(this);
            item.setGravity(Gravity.CENTER_VERTICAL);
            item.setOrientation(LinearLayout.HORIZONTAL);
            item.setPadding(dp(14), dp(10), dp(14), dp(10));
            item.setBackground(round(panel, 12));
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, dp(54));
            ip.bottomMargin = dp(7);
            root.addView(item, ip);
            TextView dot = text("•", 24, accent, true);
            item.addView(dot, new LinearLayout.LayoutParams(dp(30), -2));
            TextView name = text(label, 15, fg, false);
            item.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
            TextView arrow = text("↗", 17, muted, false);
            item.addView(arrow);
            String packageName = info.activityInfo.packageName;
            String className = info.activityInfo.name;
            item.setOnClickListener(v -> {
                Intent launch = new Intent(Intent.ACTION_MAIN);
                launch.addCategory(Intent.CATEGORY_LAUNCHER);
                launch.setClassName(packageName, className);
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try { startActivity(launch); } catch (Exception ignored) { }
            });
            shown++;
            if (shown >= 30) break;
        }
        if (shown == 0) {
            TextView empty = text("Nenhum aplicativo encontrado.", 14, muted, false);
            root.addView(empty);
        }
    }

    private void refreshRam() {
        if (ramValue == null || ramDetail == null) return;
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        long total = mi.totalMem;
        long available = mi.availMem;
        long used = Math.max(0, total - available);
        int percent = total > 0 ? (int) ((used * 100L) / total) : 0;
        ramValue.setText(percent + "%");
        ramDetail.setText(formatBytes(available) + " disponíveis de " + formatBytes(total));
    }

    private String formatBytes(long bytes) {
        double gb = bytes / (1024.0 * 1024.0 * 1024.0);
        if (gb >= 1.0) return String.format(Locale.getDefault(), "%.1f GB", gb);
        double mb = bytes / (1024.0 * 1024.0);
        return String.format(Locale.getDefault(), "%.0f MB", mb);
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(12);
        b.setLetterSpacing(0.06f);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setTextColor(primary ? bg : fg);
        b.setBackground(round(primary ? accent : panel, 12));
        return b;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
