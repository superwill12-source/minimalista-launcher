# Minimalista iOS Style 2.0

Launcher Android inspirado na organização visual do iPhone, sem copiar software proprietário.

Recursos: relógio e data, fundo em gradiente, ícones reais dos apps instalados em grade, busca, dock inferior, biblioteca de aplicativos, ocultação por toque longo, widget de leitura da memória e seleção como tela inicial padrão.

Nota: o widget exibe informação de memória do sistema, não força limpeza de RAM. O dock usa atalhos por nome aproximado; se o app não existir, mostra aviso. Recursos iOS exclusivos não estão incluídos.

## Compilar
JDK 17 e Android SDK API 35. Execute `gradle assembleDebug` no diretório do projeto. APK: `app/build/outputs/apk/debug/app-debug.apk`.
