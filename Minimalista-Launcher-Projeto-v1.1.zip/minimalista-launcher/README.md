# Minimalista Launcher (Android)

Projeto inicial de launcher Android nativo em Java, com interface escura minimalista, lista de aplicativos instalados, leitura da RAM do sistema e atalho para configurações de aplicativos.

## Funcionalidades
- Pode ser selecionado como aplicativo de tela inicial (HOME) do Android.
- Mostra relógio/data na abertura.
- Lista até 30 aplicativos lançáveis, em ordem alfabética.
- Mostra RAM usada estimada e memória disponível, usando as informações que o Android fornece.
- Botão para atualizar a leitura e atalho para configurações de aplicativos.

## Limite importante da função de RAM
O botão atualiza a leitura; ele não força o encerramento de outros aplicativos. Android 14 ou superior impede que aplicativos comuns encerrem processos em segundo plano de outros apps. O sistema gerencia a RAM automaticamente.

## Compilação
Requer Android Studio ou ambiente com Android SDK (API 35), JDK 17+ e Gradle compatível com Android Gradle Plugin 8.7.3. Abra a pasta do projeto no Android Studio e use **Build > Build APK(s)**. O APK de depuração costuma ficar em `app/build/outputs/apk/debug/app-debug.apk`.

Este ambiente de criação não tem Android SDK nem Gradle instalados, então o APK não pôde ser compilado aqui. O projeto-fonte está pronto para abrir e compilar no Android Studio.
