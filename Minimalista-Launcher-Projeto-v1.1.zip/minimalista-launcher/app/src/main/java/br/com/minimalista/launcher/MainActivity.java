package br.com.minimalista.launcher;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private final int bg=Color.rgb(12,14,13), panel=Color.rgb(25,29,25), fg=Color.rgb(241,245,237), muted=Color.rgb(155,166,151), accent=Color.rgb(184,243,107);
    private LinearLayout root, appsList;
    private TextView ramValue, ramDetail, clock, date;
    private EditText search;
    private final List<ResolveInfo> allApps=new ArrayList<>();
    private PackageManager pm;
    private SharedPreferences prefs;
    private final Map<String,String> iconMarks=new HashMap<>();
    private final String[] marks={"●","◆","✦","○","▲","■","✳","◈"};

    @Override public void onCreate(Bundle b){super.onCreate(b); pm=getPackageManager(); prefs=getSharedPreferences("launcher",MODE_PRIVATE); getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg); buildUi();}
    @Override protected void onResume(){super.onResume(); updateClock(); refreshRam();}

    private void buildUi(){
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(bg);
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(22),dp(24),dp(22),dp(28)); scroll.addView(root);
        TextView brand=text("MINIMALISTA  /  HOME",11,accent,true); brand.setLetterSpacing(.18f); root.addView(brand);
        clock=text("--:--",56,fg,true); clock.setPadding(0,dp(12),0,0); root.addView(clock);
        date=text("",14,muted,false); date.setPadding(0,0,0,dp(22)); root.addView(date);
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(18),dp(16),dp(18),dp(16)); card.setBackground(round(panel,20)); root.addView(card,params(-1,-2,0,0,0,dp(22)));
        TextView ramTitle=text("MEMÓRIA DO SISTEMA",11,muted,true); ramTitle.setLetterSpacing(.12f); card.addView(ramTitle);
        ramValue=text("--%",34,accent,true); ramValue.setPadding(0,dp(5),0,0); card.addView(ramValue);
        ramDetail=text("Lendo memória…",13,muted,false); ramDetail.setPadding(0,dp(2),0,dp(12)); card.addView(ramDetail);
        TextView refresh=button("↻   Atualizar leitura",true); card.addView(refresh,params(-1,dp(44),0,0,0,0)); refresh.setOnClickListener(v->refreshRam());
        search=new EditText(this); search.setSingleLine(true); search.setTextColor(fg); search.setHintTextColor(muted); search.setHint("⌕   Buscar aplicativos..."); search.setTextSize(15); search.setPadding(dp(16),0,dp(16),0); search.setBackground(round(panel,16)); root.addView(search,params(-1,dp(52),0,0,0,dp(22)));
        LinearLayout heading=new LinearLayout(this); heading.setGravity(Gravity.CENTER_VERTICAL); heading.setOrientation(LinearLayout.HORIZONTAL); root.addView(heading,params(-1,-2,0,0,0,dp(10)));
        TextView title=text("SEUS APLICATIVOS",11,muted,true); title.setLetterSpacing(.12f); heading.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        TextView hideInfo=text("segure para ocultar",11,muted,false); heading.addView(hideInfo);
        appsList=new LinearLayout(this); appsList.setOrientation(LinearLayout.VERTICAL); root.addView(appsList);
        TextView gestures=text("DICA  ·  Toque para abrir • toque duas vezes no painel de RAM para atualizar",11,muted,false); gestures.setPadding(dp(2),dp(18),dp(2),dp(10)); root.addView(gestures);
        card.setOnTouchListener(new View.OnTouchListener(){long last=0; public boolean onTouch(View v,android.view.MotionEvent e){if(e.getAction()==android.view.MotionEvent.ACTION_UP){long now=System.currentTimeMillis(); if(now-last<450){refreshRam();last=0;return true;}last=now;}return true;}});
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){renderApps(s.toString());}public void afterTextChanged(Editable e){}});
        loadApps(); setContentView(scroll); updateClock(); refreshRam();
    }
    private void loadApps(){allApps.clear(); Intent q=new Intent(Intent.ACTION_MAIN,null);q.addCategory(Intent.CATEGORY_LAUNCHER);List<ResolveInfo> found=pm.queryIntentActivities(q,0); Collections.sort(found,(a,b)->a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString()));String own=getPackageName();for(ResolveInfo r:found)if(r.activityInfo!=null&&!own.equals(r.activityInfo.packageName))allApps.add(r);renderApps("");}
    private void renderApps(String filter){if(appsList==null)return;appsList.removeAllViews();String f=filter.trim().toLowerCase(Locale.getDefault());int count=0;
        for(ResolveInfo r:allApps){String pkg=r.activityInfo.packageName,label=r.loadLabel(pm).toString();if(prefs.getBoolean("hidden_"+pkg,false)||(!f.isEmpty()&&!label.toLowerCase(Locale.getDefault()).contains(f)))continue;
            LinearLayout item=new LinearLayout(this);item.setGravity(Gravity.CENTER_VERTICAL);item.setPadding(dp(14),dp(8),dp(12),dp(8));item.setBackground(round(panel,15));appsList.addView(item,params(-1,dp(58),0,0,0,dp(7)));
            TextView mark=text(prefs.getString("mark_"+pkg,"✦"),22,accent,true);mark.setGravity(Gravity.CENTER);item.addView(mark,new LinearLayout.LayoutParams(dp(38),-1));
            TextView name=text(label,15,fg,false);name.setPadding(dp(8),0,0,0);item.addView(name,new LinearLayout.LayoutParams(0,-2,1));TextView arrow=text("↗",17,muted,false);item.addView(arrow);
            item.setOnClickListener(v->{Intent launch=new Intent(Intent.ACTION_MAIN);launch.addCategory(Intent.CATEGORY_LAUNCHER);launch.setClassName(pkg,r.activityInfo.name);try{startActivity(launch);}catch(Exception ignored){}});
            item.setOnLongClickListener(v->{new AlertDialog.Builder(this).setTitle(label).setItems(new String[]{"Personalizar símbolo","Ocultar aplicativo"},(d,which)->{if(which==0)chooseMark(pkg);else{prefs.edit().putBoolean("hidden_"+pkg,true).apply();renderApps(search.getText().toString());}}).setNegativeButton("Cancelar",null).show();return true;});count++;
        }
        if(count==0){TextView empty=text(f.isEmpty()?"Nenhum app disponível.":"Nenhum resultado para essa busca.",14,muted,false);empty.setPadding(dp(4),dp(16),0,dp(16));appsList.addView(empty);}
    }
    private void chooseMark(String pkg){new AlertDialog.Builder(this).setTitle("Escolha um símbolo").setItems(marks,(d,w)->{prefs.edit().putString("mark_"+pkg,marks[w]).apply();renderApps(search.getText().toString());}).setNeutralButton("Gerenciar apps ocultos",(d,w)->manageHidden()).show();}
    private void manageHidden(){List<String> labels=new ArrayList<>(),pkgs=new ArrayList<>();for(ResolveInfo r:allApps){String p=r.activityInfo.packageName;if(prefs.getBoolean("hidden_"+p,false)){pkgs.add(p);labels.add(r.loadLabel(pm).toString());}}if(pkgs.isEmpty()){new AlertDialog.Builder(this).setMessage("Não há aplicativos ocultos.").setPositiveButton("OK",null).show();return;}String[] arr=labels.toArray(new String[0]);new AlertDialog.Builder(this).setTitle("Toque para mostrar novamente").setItems(arr,(d,w)->{prefs.edit().putBoolean("hidden_"+pkgs.get(w),false).apply();renderApps(search.getText().toString());}).setPositiveButton("Fechar",null).show();}
    private void updateClock(){if(clock==null)return;Date now=new Date();clock.setText(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(now));date.setText(new SimpleDateFormat("EEEE, d 'de' MMMM",new Locale("pt","BR")).format(now));}
    private void refreshRam(){if(ramValue==null)return;ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE);ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo();am.getMemoryInfo(mi);long total=mi.totalMem,avail=mi.availMem,used=Math.max(0,total-avail);int p=total>0?(int)(used*100L/total):0;ramValue.setText(p+"% utilizado");ramDetail.setText(format(used)+" em uso  ·  "+format(avail)+" disponíveis de "+format(total));}
    private String format(long n){double gb=n/(1024.0*1024*1024);return gb>=1?String.format(Locale.getDefault(),"%.1f GB",gb):String.format(Locale.getDefault(),"%.0f MB",n/(1024.0*1024));}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private TextView button(String s,boolean primary){TextView t=text(s,13,bg,true);t.setGravity(Gravity.CENTER);t.setBackground(round(primary?accent:panel,13));return t;}
    private GradientDrawable round(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private LinearLayout.LayoutParams params(int w,int h,int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(l,t,r,b);return p;}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
}
